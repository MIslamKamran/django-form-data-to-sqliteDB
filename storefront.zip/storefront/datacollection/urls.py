from django.urls import path
from . import views

urlpatterns = [
    path('fruits/', views.fruits,name='fruits'),
    path('games/', views.games,name='games'),
    path('devices/', views.devices,name='devices'),
]