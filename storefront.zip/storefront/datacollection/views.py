from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Fruit
from .models import Game
from .models import Device

def fruits(request):
    if request.method == 'POST':
        fruit = request.POST['fruit']#fruit table
        fruitdata = Fruit(fruit_data=fruit)

        fruitdata.save()
    # template = loader.get_template('index.html')
    # return HttpResponse(template.render())
    return render(request, 'index1.html', {})


def games(request):
    if request.method == 'POST':
        game = request.POST['game']
        game_data = Game(game_data=game)

        game_data.save()
    return render(request, 'index1.html', {})


def devices(request):
    if request.method == 'POST':
        device = request.POST['device']
        device_data = Device(device_data = device)
        device_data.save()
    return render(request, 'index1.html', {})