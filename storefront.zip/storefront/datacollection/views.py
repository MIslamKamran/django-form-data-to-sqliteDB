from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import *
# from .models import Fruit
# from .models import Game
# from .models import Device

def fruits(request):
    if request.method == 'POST':
        fruit = request.POST['fruit']#fruit table
        vegi = request.POST['vegi']#fruit table
        fruitdata = Fruit(fruit_data = fruit)
        vegidata = Fruit(vegi_data = vegi)

        fruitdata.save()
        vegidata.save()

    # template = loader.get_template('index.html')
    # return HttpResponse(template.render())
    return render(request, 'index1.html', {})


def games(request):
    if request.method == 'POST':
        game = request.POST['game']
        level = request.POST['level']
        game_data = Game(game_data=game)
        game_level = Game(game_level=level)

        game_data.save()
        game_level.save()
    return render(request, 'index1.html', {})


def devices(request):
    if request.method == 'POST':
        device = request.POST['device']
        device_data = Device(device_data = device)
        device_data.save()
    return render(request, 'index1.html', {})