from django.db import models

# Create your models here.
class Fruit(models.Model):
    fruit_data = models.TextField()
class Game(models.Model):
    game_data = models.TextField()
class Device(models.Model):
    device_data = models.TextField()

    def __str__(self):
        return self.title
