from django.db import models

# Create your models here.
class Fruit(models.Model):
    fruit_data = models.CharField(max_length=100)
    vegi_data = models.CharField(max_length=100)
class Game(models.Model):
    game_data = models.CharField(max_length=100)
    game_level = models.CharField(max_length=100)
class Device(models.Model):
    device_data = models.CharField(max_length=100)

    def __str__(self):
        return self.title
